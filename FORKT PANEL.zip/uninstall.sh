#!/system/bin/sh

TARGET="lex.sh"
ASU="stats.sh"

rm -f /data/local/tmp/forkt.pid
rm -f /data/local/tmp/forkt_cpu_prev
rm -f /data/local/tmp/forkt_stats.json
rm -f /data/local/tmp/device.json
pkill -9 -f forkt.json
pkill -9 -f stats.sh
# ===== Cari PID =====
pid_target=$(pgrep -f "$TARGET")
pid_asu=$(pgrep -f "$ASU")

# ===== Kill Proses =====
[ -n "$pid_target" ] && { kill -9 "$pid_target"; sleep 0.3; }
[ -n "$pid_asu" ] && { kill -9 "$pid_asu"; sleep 0.3; }

# ===== Cek Apakah Masih Hidup =====
pid_after=$(pgrep -f "$TARGET")

if [ -z "$pid_after" ]; then
    am start -a AxManager.TOAST -e text "Frokt Deactivated"
else
    am start -a AxManager.TOAST -e text "Deactivated Forkt Denied"
fi
#!/system/bin/sh
OUT="/data/local/tmp/device.json"

detect_chipset() {
  RAW="$(cat /proc/cpuinfo 2>/dev/null;
         getprop ro.hardware;
         getprop ro.board.platform)"
  RAW="$(echo "$RAW" | tr 'A-Z' 'a-z')"

  if echo "$RAW" | grep -Eq "mediatek|mt6|mt7|mt8|dimensity|helio"; then
    CHIPSET_ID="mediatek"
    CHIPSET_NAME="MediaTek"
  elif echo "$RAW" | grep -Eq "qualcomm|qcom|sm[0-9]{2}|snapdragon|kryo"; then
    CHIPSET_ID="snapdragon"
    CHIPSET_NAME="Snapdragon"
  elif echo "$RAW" | grep -Eq "unisoc|spreadtrum|sprd|ums"; then
    CHIPSET_ID="unisoc"
    CHIPSET_NAME="Unisoc"
  else
    CHIPSET_ID="unknown"
    CHIPSET_NAME="Unknown"
  fi
}

detect_rom() {
  RAW="$(getprop ro.miui.ui.version.name;
         getprop ro.build.display.id;
         getprop ro.build.flavor;
         getprop ro.product.brand;
         getprop ro.vivo.os.name)"
  RAW="$(echo "$RAW" | tr 'A-Z' 'a-z')"

  if echo "$RAW" | grep -Eq "miui|hyperos|xiaomi|redmi"; then
    ROM_ID="miui"
    ROM_NAME="MIUI / HyperOS"
  elif echo "$RAW" | grep -Eq "xos|infinix|tecno|transsion"; then
    ROM_ID="xos"
    ROM_NAME="XOS"
  elif echo "$RAW" | grep -Eq "funtouch|vivo"; then
    ROM_ID="funtouch"
    ROM_NAME="Funtouch OS"
  elif echo "$RAW" | grep -Eq "aosp|lineage|pixel"; then
    ROM_ID="aosp"
    ROM_NAME="AOSP / Custom"
  else
    ROM_ID="unknown"
    ROM_NAME="Unknown"
  fi
}

# === RUN ===
detect_chipset
detect_rom

# === WRITE JSON (no EOF) ===
printf '{\n' > "$OUT"
printf '  "chipset": {\n' >> "$OUT"
printf '    "id": "%s",\n' "$CHIPSET_ID" >> "$OUT"
printf '    "name": "%s"\n' "$CHIPSET_NAME" >> "$OUT"
printf '  },\n' >> "$OUT"
printf '  "rom": {\n' >> "$OUT"
printf '    "id": "%s",\n' "$ROM_ID" >> "$OUT"
printf '    "name": "%s"\n' "$ROM_NAME" >> "$OUT"
printf '  }\n' >> "$OUT"
printf '}\n' >> "$OUT"

chmod 644 "$OUT"
echo "[OK] Device info saved to $OUT"
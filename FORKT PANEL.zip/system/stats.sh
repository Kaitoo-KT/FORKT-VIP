#!/system/bin/sh
# =============================================
# Forkt Device Stats JSON - Realtime
# =============================================

OUT="/data/local/tmp/forkt_stats.json"
CPU_PREV="/data/local/tmp/forkt_cpu_prev"

while true; do

# ========= RAM =========
MEM_TOTAL=$(awk '/MemTotal:/ {print $2}' /proc/meminfo)
MEM_AVAIL=$(awk '/MemAvailable:/ {print $2}' /proc/meminfo)

MEM_USED=$((MEM_TOTAL - MEM_AVAIL))
RAM_PERCENT=$((MEM_USED * 100 / MEM_TOTAL))

RAM_USED_MB=$((MEM_USED / 1024))
RAM_TOTAL_MB=$((MEM_TOTAL / 1024))
RAM="${RAM_USED_MB} MB / ${RAM_TOTAL_MB} MB"

# ========= STORAGE =========
DF_LINE=$(df -k /data 2>/dev/null | awk 'NR==2')

FS_TOTAL=$(echo "$DF_LINE" | awk '{print int($2)}')
FS_USED=$(echo "$DF_LINE" | awk '{print int($3)}')

# fallback aman
[ -z "$FS_TOTAL" ] && FS_TOTAL=1
[ -z "$FS_USED" ] && FS_USED=0

# clamp agar tidak minus / overflow
[ "$FS_USED" -gt "$FS_TOTAL" ] && FS_USED="$FS_TOTAL"

STORAGE_PERCENT=$(df /data | awk 'NR==2 {gsub("%","",$5); print $5}')

# clamp 0–100
[ "$STORAGE_PERCENT" -lt 0 ] && STORAGE_PERCENT=0
[ "$STORAGE_PERCENT" -gt 100 ] && STORAGE_PERCENT=100

ST_USED_GB=$(( FS_USED / 1024 / 1024 ))
ST_TOTAL_GB=$(( FS_TOTAL / 1024 / 1024 ))

STORAGE="${ST_USED_GB} GB / ${ST_TOTAL_GB} GB"

# ========= CPU =========
CPU_LINE=$(awk '/^cpu / {print $2,$3,$4,$5,$6,$7,$8,$9}' /proc/stat)

set -- $CPU_LINE
CPU_USER=$1
CPU_NICE=$2
CPU_SYS=$3
CPU_IDLE=$4
CPU_IOWAIT=$5
CPU_IRQ=$6
CPU_SOFTIRQ=$7
CPU_STEAL=$8

CPU_TOTAL=$((CPU_USER+CPU_NICE+CPU_SYS+CPU_IDLE+CPU_IOWAIT+CPU_IRQ+CPU_SOFTIRQ+CPU_STEAL))
CPU_IDLE_ALL=$((CPU_IDLE+CPU_IOWAIT))

if [ -f "$CPU_PREV" ]; then
  read PREV_TOTAL PREV_IDLE < "$CPU_PREV"

  DIFF_TOTAL=$((CPU_TOTAL - PREV_TOTAL))
  DIFF_IDLE=$((CPU_IDLE_ALL - PREV_IDLE))

  if [ "$DIFF_TOTAL" -gt 0 ]; then
    CPU_PERCENT=$(( (DIFF_TOTAL - DIFF_IDLE) * 100 / DIFF_TOTAL ))
  else
    CPU_PERCENT=0
  fi
else
  CPU_PERCENT=0
fi

echo "$CPU_TOTAL $CPU_IDLE_ALL" > "$CPU_PREV"
CPU="${CPU_PERCENT}%"

# ========= UPTIME =========
UPTIME_SEC=$(awk '{print int($1)}' /proc/uptime)
DAYS=$((UPTIME_SEC / 86400))
HOURS=$(( (UPTIME_SEC % 86400) / 3600 ))
MINS=$(( (UPTIME_SEC % 3600) / 60 ))
UPTIME="${DAYS}d ${HOURS}h ${MINS}m"

# ========= WRITE JSON (NO EOF) =========
printf '{\n' > "$OUT"
printf '  "ram": "%s",\n' "$RAM" >> "$OUT"
printf '  "ramPercent": %d,\n' "$RAM_PERCENT" >> "$OUT"
printf '  "cpu": "%s",\n' "$CPU" >> "$OUT"
printf '  "cpuPercent": %d,\n' "$CPU_PERCENT" >> "$OUT"
printf '  "storage": "%s",\n' "$STORAGE" >> "$OUT"
printf '  "storagePercent": %d,\n' "$STORAGE_PERCENT" >> "$OUT"
printf '  "uptime": "%s"\n' "$UPTIME" >> "$OUT"
printf '}\n' >> "$OUT"

sleep 1
done
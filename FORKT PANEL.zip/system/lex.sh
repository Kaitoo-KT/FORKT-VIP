#!/system/bin/sh

### =========================
### FORKT ENGINE (STABLE)
### =========================

PIDFILE="/data/local/tmp/forkt.pid"
ENGINE_PROP="debug.forkt"
LOGIN_NOTIF_PROP="debug.forkt.login"
# =========================
# SINGLE INSTANCE GUARD
# =========================
if [ -f "$PIDFILE" ]; then
  OLD_PID="$(cat "$PIDFILE" 2>/dev/null)"
  if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
    # engine sudah jalan
    exit 0
  fi
fi

echo $$ > "$PIDFILE"

cleanup() {
  rm -f "$PIDFILE"
  exit 0
}

trap cleanup INT TERM
# =========================
# PATH RESOLVE
# =========================
SELF="$(readlink -f "$0" 2>/dev/null || echo "$0")"
BASE_DIR="$(cd "$(dirname "$SELF")" && pwd)"
GAME_LIST="$BASE_DIR/game.txt"

ENGINE_ON=0

# =========================
# APPLY ENGINE ON
# =========================
engine_on() {
  a=$(cmd window size reset;cmd window size|cut -d' ' -f3) b=${a%x*} c=${a#*x};cmd window size $(echo "$b*125/100"|bc)x$(echo "$c*125/100"|bc);cmd window density reset

  settings put secure multi_press_timeout 50
  settings put secure long_press_timeout 150
  settings put system view.scroll_friction 150

  setprop "$ENGINE_PROP" 1
  ENGINE_ON=1

  if [ "$(getprop $LOGIN_NOTIF_PROP)" = "1" ]; then
  sleep 0.3
  am start -a AxManager.TOAST -e text "Forkt Running" >/dev/null 2>&1 \
  || log -t FORKT "Forkt Running"
fi
}

# =========================
# APPLY ENGINE OFF
# =========================
engine_off() {
  cmd window size reset
  settings put secure multi_press_timeout 200
  settings put secure long_press_timeout 300
  settings put system view.scroll_friction 120

  setprop "$ENGINE_PROP" 0
  ENGINE_ON=0

  if [ "$(getprop $LOGIN_NOTIF_PROP)" = "1" ]; then
  sleep 0.3
    am start -a AxManager.TOAST -e text "Forkt Stopped" >/dev/null 2>&1
  fi
}

# =========================
# RESTORE STATE (SAFE)
# =========================
if [ "$(getprop "$ENGINE_PROP")" = "1" ]; then
  engine_on
fi
echo $$ > "$PIDFILE"
# =========================
# MAIN LOOP
# =========================
while true; do
  CURRENT_APP="$(dumpsys window 2>/dev/null \
    | grep -m 1 mCurrentFocus \
    | sed -E 's/.* ([^\/]+)\/.*/\1/')"

  if [ -n "$CURRENT_APP" ] && grep -qx "$CURRENT_APP" "$GAME_LIST"; then
    [ "$ENGINE_ON" -eq 0 ] && engine_on
  else
    [ "$ENGINE_ON" -eq 1 ] && engine_off
  fi

  sleep 2
done
#!/system/bin/sh
OUTFILE="/data/local/tmp/applist.json"
ICON_DIR="/data/local/tmp/applist-icons"

mkdir -p "$ICON_DIR"
echo "[" > $OUTFILE

first=true
while read -r pkg; do
  if pm list packages | grep -q "^package:$pkg$"; then
    # nama aplikasi
    label=$(dumpsys package "$pkg" | grep -m1 "application-label:" | sed "s/application-label:'\(.*\)'/\1/")
    [ -z "$label" ] && label="$pkg"

    # icon ke base64
    APK_PATH=$(pm path "$pkg" | cut -d':' -f2)
    ICON_PATH=$(aapt dump badging "$APK_PATH" | grep application-icon-160 | head -n1 | cut -d"'" -f2)

    if [ -n "$ICON_PATH" ]; then
      unzip -p "$APK_PATH" "$ICON_PATH" | base64 > "$ICON_DIR/$pkg.b64"
      ICON_DATA="data:image/png;base64,$(cat "$ICON_DIR/$pkg.b64")"
    else
      ICON_DATA=""
    fi

    [ "$first" = true ] && first=false || echo "," >> $OUTFILE
    echo "{\"pkg\":\"$pkg\",\"name\":\"$label\",\"icon\":\"$ICON_DATA\"}" >> $OUTFILE
  fi
done < /data/local/tmp/game.txt

echo "]" >> $OUTFILE
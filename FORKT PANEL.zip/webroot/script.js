import { exec } from "https://cdn.jsdelivr.net/npm/kernelsu@1.0.6/+esm";

/* ========= ELEMENT ========= */
const BtnOn = document.getElementById('BtnOnSmart');
const BtnOff = document.getElementById('BtnOffSmart');
const StsEngine = document.getElementById('sts-engine-id');
const CurrentTime = document.getElementById('current-time-id');
const StatusCard = document.querySelector('.status-engine');
const VersionCard = document.querySelector('.version-plugin');
const SupportLink = document.getElementById('support-link');
const TouchSlider = document.getElementById("touch-sensitivity");
const TouchValue  = document.getElementById("touch-value");
const tabBtns = document.querySelectorAll(".tab-btn");
const tabs = {
  control: document.getElementById("tab-control"),
  device: document.getElementById("tab-device"),
  settings: document.getElementById("tab-settings")
};
const PidText = document.getElementById('engine-pid-id');
const PidBanner = document.getElementById('banner-pid');
/* Device stats elements */
const ramUsage = document.getElementById("ram-usage");
const cpuUsage = document.getElementById("cpu-usage");
const storageUsage = document.getElementById("storage-usage");
const deviceUptime = document.getElementById("device-uptime");
const ramBar = document.getElementById("ram-bar");
const cpuBar = document.getElementById("cpu-bar");
const storageBar = document.getElementById("storage-bar");
const SfApplyBtn = document.getElementById("sf-apply");
const SfResetBtn = document.getElementById("sf-reset");
const SfFpsText = document.getElementById("sf-fps");
const statusEl = document.getElementById("device-action-status");
const badge = document.getElementById("engine-badge");
const frameToggle = document.getElementById("frame-optimizer-toggle");
const chipsetNameEl = document.getElementById("chipset-name");
const chipsetBadge  = document.getElementById("chipset-badge");
const chipsetToggle = document.getElementById("chipset-boost-toggle");
const romNameEl  = document.getElementById("rom-name");
const romBadge   = document.getElementById("rom-badge");
const romToggle  = document.getElementById("rom-boost-toggle");
const loggingToggle = document.getElementById("logging-toggle");
const loginNotifToggle = document.getElementById("login-notif-toggle");
const adminPanel = document.getElementById("admin-panel");
const adminToggle = document.getElementById("admin-toggle");
const freeAddBtn = document.getElementById("free-add");
/* ========= STATE ========= */
const CURRENT_VERSION = "1.0.5";

let activeTab = "control";
let tabLocked = false;
let engineActionLock = false;
let engineDesiredState = false;
let engineActualState = false;
let enginePID = null;
let engineBooting = false;
const ENGINE_BOOT_GRACE = 8000; // 8 detik
let engineForceOffUntil = 0; // guard setelah OFF
const ENGINE_OFF_GUARD = 3000;
let engineBootStart = 0;
let statsInterval;
let detectedChipset = "unknown";
let detectedRom = "unknown";
import { isVipUser } from './vip.js';
//STATE
const LOGIN_PROP = "debug.forkt.login";
const LOGIN_KEY  = "forkt_login_notif";
const STORE_KEY = "forkt_state";
function loadState() {
  try {
    return JSON.parse(localStorage.getItem(STORE_KEY)) || {};
  } catch {
    return {};
  }
}
function getSaved(key, def = false) {
  const state = loadState();
  return key in state ? state[key] : def;
}
function saveState(patch) {
  const current = loadState();
  localStorage.setItem(STORE_KEY, JSON.stringify({
    ...current,
    ...patch
  }));
}
/* ========= UTIL ========= */
const sleep = ms => new Promise(r => setTimeout(r, ms));
async function checkUpdate() {
  try {
    const res = await fetch(
      "https://raw.githubusercontent.com/Kaitoo-KT/FORKT-VIP/main/version.json",
      { cache: "no-store" }
    );
    if (!res.ok) return;

    const data = await res.json();
    if (!data.version) return;

    if (data.version !== CURRENT_VERSION) {
      const card = document.getElementById("update-card");
      const versionEl = document.getElementById("update-version");
      const descEl = document.getElementById("update-desc");

      card.style.display = "block";
      versionEl.textContent = data.version;

      // 👉 FIX NOTES
      if (Array.isArray(data.notes)) {
        descEl.innerHTML = data.notes
          .map(n => `• ${n}`)
          .join("<br>");
      } else {
        descEl.textContent = "Update tersedia";
      }

      document.getElementById("update-btn").onclick = () => {
        window.open("http://forktpanel.diskon.cloud/", "_blank");
      };
    }
  } catch (e) {
    console.log("[UPDATE] skipped", e);
  }
}
function setProgress(bar, percent) {
  if (!bar) return;

  const p = Math.max(0, Math.min(100, percent));

  bar.style.width = `${p}%`;

  bar.classList.remove(
    "progress-green",
    "progress-yellow",
    "progress-red"
  );

  if (p < 60) {
    bar.classList.add("progress-green");
  } else if (p < 85) {
    bar.classList.add("progress-yellow");
  } else {
    bar.classList.add("progress-red");
  }
}
async function detectDeviceShell() {
  // ===== DEFAULT SAFE =====
  detectedChipset = "unknown";
  detectedRom = "unknown";

  chipsetNameEl.textContent = "Unknown";
  chipsetBadge.textContent = "UNKNOWN";

  romNameEl.textContent = "Unknown";
  romBadge.textContent = "UNKNOWN";

  try {
    const { stdout } = await exec(
      "cat /data/local/tmp/device.json 2>/dev/null"
    );

    if (!stdout || !stdout.trim().startsWith("{")) {
      throw new Error("device.json not found or invalid");
    }

    const device = JSON.parse(stdout);

    // ===== CHIPSET =====
    if (device.chipset) {
      detectedChipset = device.chipset.id || "unknown";
      chipsetNameEl.textContent = device.chipset.name || "Unknown";
      chipsetBadge.textContent = detectedChipset.toUpperCase();
    }

    // ===== ROM =====
    if (device.rom) {
      detectedRom = device.rom.id || "unknown";
      romNameEl.textContent = device.rom.name || "Unknown";
      romBadge.textContent = detectedRom.toUpperCase();
    }

  } catch (err) {
    console.warn("[DetectDevice] fallback UNKNOWN", err);
    // fallback tetap UNKNOWN
  }

  // ===== UPDATE UI AVAILABILITY =====
  updateChipsetBoostAvailability();
  updateRomBoostAvailability();
  refreshAllBadges();
}
async function initBoostStates() {
  const chipsetSaved = getSaved("chipsetBoost", false);
  const romSaved = getSaved("romBoost", false);

  // === CHIPSET ===
  if (chipsetSaved && detectedChipset !== "unknown") {
    chipsetToggle.checked = true;
    try {
      await applyChipsetBoost(true);
    } catch {
      chipsetToggle.checked = false;
      saveState({ chipsetBoost: false });
    }
  } else {
    chipsetToggle.checked = false;
  }

  // === ROM ===
  if (romSaved && detectedRom !== "unknown") {
    romToggle.checked = true;
    try {
      await applyRomBoost(true);
    } catch {
      romToggle.checked = false;
      saveState({ romBoost: false });
    }
  } else {
    romToggle.checked = false;
  }

  refreshAllBadges();
}
async function applyDisableLogging(enable) {
  if (enable) {
    await exec(`
      {
        setprop log.tag S
        setprop log.tag.stats_log S
        setprop persist.traced.enable 0
        setprop persist.traced_perf.enable 0

        for a in $(cmd package list packages --user 0|cut -f2 -d:);do cmd package log-visibility --disable "$a"&done;getprop|grep log.tag|cut -f1 -d]|sed 's|\[|setprop |;s|$| S&|'|sh;atrace --async_stop>/dev/null;cmd accessibility stop-trace;cmd activity logging disable-text;cmd autofill set log_level off;cmd display ab-logging-disable;cmd display dmd-logging-disable;cmd display dwb-logging-disable;cmd input_method tracing stop;cmd migard dump-trace false;cmd migard start-trace false;cmd migard stop-trace true;cmd migard trace-buffer-size 0;cmd miui_step_counter_service logging-disable;cmd statusbar tracing stop;cmd voiceinteraction set-debug-hotword-logging false;cmd wifi set-verbose-logging disabled -l 0;cmd window logging disable;cmd window logging disable-text;cmd window logging stop;cmd window tracing size 0;echo 0>/sys/kernel/tracing/tracing_on;ime tracing stop
      } &>/dev/null
    `);

    showToast("Logging disabled");
  } else {
    await exec(`
      {
        cmd display ab-logging-enable
        cmd display dwb-logging-enable
        cmd display dmd-logging-enable

        cmd binder_calls_stats --reset
        cmd looper_stats reset

        cmd autofill reset
        cmd miui_step_counter_service logging-enable
        cmd voiceinteraction set-debug-hotword-logging true
        cmd wifi set-verbose-logging enabled -l 0
        cmd window logging enable
        dumpsys procstats --reset
      } &>/dev/null
    `);

    showToast("Logging restored");
  }
}
async function applyRomBoost(enable) {
  // ==== OFF ====
  if (!enable) {
    showToast("ROM Boost disabled");
    return;
  }

  // ==== VALIDASI ====
  if (!detectedRom || detectedRom === "unknown") {
    throw new Error("ROM not supported");
  }

  showToast("Applying ROM Boost…");

  try {
    // ===== MIUI =====
    if (detectedRom === "miui") {
      await exec(`
        sh -c "
        setprop debug.power.monitor_tools false

        settings put system power_mode high
        settings put system POWER_SAVE_PRE_HIDE_MODE ultimate
        settings put secure speed_mode 1

        settings list system | grep -q POWER_PERFORMANCE_MODE_OPEN && \
        settings put system POWER_PERFORMANCE_MODE_OPEN 1
        for a in $(dumpsys content|grep -o cloud_turbo.*enable.*|cut -f1 -d:);do cmd settings put system "$a" true;done
        "
      `);
    }

    // ===== XOS / Transsion =====
    else if (detectedRom === "xos") {
      await exec(`
        sh -c "
        settings put system settings_game_enhance_strength 1
        settings put system settings_game_performance_mode 1
        settings put system tran_cpupower_mode 1

        settings put secure transsion_game_function_mode 2

        settings put global fpsgo_support_status enable
        settings put global transsion_game_acceleration 1
        settings put global transsion_game_picture_optimization 1
        settings put global tran_signal_smooth_enable 1
        settings put global game_space_network_dual_channel 1
        settings put global tran_temp_battery_warning 0
        settings put global tran_temp_battery_warning_flag 0
        "
      `);
    }

    // ===== Funtouch OS =====
    else if (detectedRom === "funtouch") {
      await exec(`
        sh -c "
        settings put global dolby_a2sd_switch 0
        settings put global dolby_head_switch 0
        settings put global dolby_speaker_switch 0

        settings put system bench_mark_mode 1
        settings put system game_do_not_disturb 1
        settings put system game_scene_more_fps 1
        settings put system gamecube_block_notification_on 1
        settings put system gamecube_block_pic_in_pic 1
        settings put system gamewatch_game_target_fps -1
        settings put system lock_game_rotation 1
        settings put system support_app_animation_window 0
        "
      `);
    }

    showToast("ROM Boost applied");

  } catch (err) {
    console.error("[RomBoost]", err);
    throw err; // ⬅️ penting untuk rollback toggle
  }
}
function updateChipsetBoostAvailability() {
  const unsupported = detectedChipset === "unknown";

  chipsetToggle.checked = false;
  chipsetToggle.disabled = unsupported;

  updateBadge(
    chipsetBadge,
    false,
    unsupported ? "UNSUPPORTED" : "DETECT"
  );
}

function updateRomBoostAvailability() {
  const unsupported = detectedRom === "unknown";

  romToggle.checked = false;
  romToggle.disabled = unsupported;

  updateBadge(
    romBadge,
    false,
    unsupported ? "UNSUPPORTED" : "DETECT"
  );
}
function refreshAllBadges() {
  /* ===== CHIPSET BADGE ===== */
  if (chipsetBadge && chipsetToggle) {
    if (detectedChipset === "unknown") {
      updateBadge(chipsetBadge, false, "UNSUPPORTED");
    } else {
      updateBadge(
        chipsetBadge,
        chipsetToggle.checked === true,
        "DETECT"
      );
    }
  }

  /* ===== ROM BADGE ===== */
  if (romBadge && romToggle) {
    if (detectedRom === "unknown") {
      updateBadge(romBadge, false, "UNSUPPORTED");
    } else {
      updateBadge(
        romBadge,
        romToggle.checked === true,
        "DETECT"
      );
    }
  }
}
function updateBadge(badgeEl, active, defaultText = "DETECT") {
  if (!badgeEl) return;

  badgeEl.classList.toggle("active", active);
  badgeEl.textContent = active ? "ACTIVE" : defaultText;
}
async function applyChipsetBoost(enable) {
  // ==== OFF ====
  if (!enable) {
    showToast("Chipset Boost disabled");
    return;
  }

  // ==== VALIDASI ====
  if (!detectedChipset || detectedChipset === "unknown") {
    throw new Error("Chipset unknown");
  }

  showToast("Applying Chipset Boost…");

  try {
    if (detectedChipset === "mediatek") {
      await exec(`
        sh -c "
        setprop debug.mediatek.appgamepq_compress 1
        setprop debug.mediatek.disp_decompress 1
        setprop debug.mediatek.appgamepq 1
        setprop debug.mediatek.game_pq_enable 1
        setprop debug.mediatek.high_frame_rate_sf_set_big_core_fps_threshold 90

        setprop debug.mtklog.netlog.Running 0
        setprop debug.mtklog.netlog.enable 0
        setprop debug.mtklog.aee.Running 0
        setprop debug.mtklog.aee.enable 0
        setprop debug.mtk.aee.db 0
        setprop debug.netlog.writtingpath disable
        setprop debug.mtklog.log2sd.path disable
        setprop debug.mtklog.init.flag 0
        setprop debug.MB.running 0
        setprop debug.mdlogger.Running 0
        "
      `);
    }

    else if (detectedChipset === "snapdragon") {
      await exec(`
        sh -c "
        setprop debug.gralloc.gfx_ubwc_disable 0
        setprop debug.qc.hardware true
        setprop debug.qctwa.statusbar 1
        setprop debug.qctwa.preservebuf 1

        setprop debug.qualcomm.sns.hal 0
        setprop debug.qualcomm.sns.daemon 0
        setprop debug.qualcomm.sns.libsensor1 0
        "
      `);
    }

    else if (detectedChipset === "unisoc") {
      await exec(`
        sh -c "
        for app in \$(cmd package list packages --user 0 | cut -f2 -d:); do
          cmd ufw settings set-preload-enable \"\$app\" true
        done
        "
      `);
    }

    showToast("Chipset Boost applied");

  } catch (err) {
    console.error("[ChipsetBoost]", err);
    throw err; // ⬅️ penting agar toggle handler bisa rollback
  }
}
async function fetchSurfaceFlingerFPS() {
  try {
    const { stdout } = await exec(
      `dumpsys display | grep -oE 'fps=[0-9]+' | head -n 1`
    );
    const fps = stdout.match(/\d+/)?.[0] || "60";
    SfFpsText.textContent = `${fps} Hz`;
    return fps;
  } catch {
    SfFpsText.textContent = "60 Hz";
    return 60;
  }
}
async function runShellAsync(cmd) {
  // jalankan shell tanpa menunggu blocking
  exec(cmd).catch(e => console.error("Shell error:", e));
}
async function applyFrameOptimizer(enable) {
  if (enable) {
    await exec(`
      WM_DEBUG_GROUPS="$(dumpsys window | grep '^ *Proto:' | sed 's/.*Proto: //' )"
      cmd window logging disable $WM_DEBUG_GROUPS
      cmd window logging disable-text $WM_DEBUG_GROUPS
      settings put global low_power 0
      settings put global low_power_sticky 0
      settings put secure speed_mode_enable 1
      current_props="$(getprop | cut -f1 -d ']')"
      eval "$(echo "$current_props" | grep -F '[log.tag' | sed 's/\[/setprop persist./g' | sed 's/$/ S/g')"
      eval "$(echo "$current_props" | grep -F '[persist.log.tag' | sed 's/\[persist./setprop /g' | sed 's/$/ S/g')"
      eval "$(echo "$current_props" | grep 'log.tag' | sed 's/\[/setprop /g' | sed 's/$/ S/g')"
    `);
    showToast("Frame Optimizer enabled");
  } else {
    await exec(`
      setprop debug.hwui.disable_vsync false
    `);
    showToast("Frame Optimizer disabled");
  }
}
function sfPulse() {
  const card = document.querySelector(".sf-card");
  card.classList.add("pulse");
  setTimeout(() => card.classList.remove("pulse"), 400);
}
async function sendFeedback(text) {
  if (!text.trim()) {
    showToast("Feedback tidak boleh kosong");
    return;
  }

  const subject = "FORKT Feedback";
  const body = `${text}

---
Device : ${navigator.userAgent}
Engine : ${document.getElementById("sts-engine-id")?.textContent || "N/A"}
Version: 1.0.3
`;

  try {
    await exec(`
      am start \
        -a android.intent.action.SENDTO \
        -d "mailto:rxysettings@gmail.com" \
        --es subject "${subject.replace(/"/g, '\\"')}" \
        --es body "${body.replace(/"/g, '\\"')}" \
        -p com.google.android.gm
    `);

    showToast("Membuka Gmail…");
  } catch (e) {
    showToast("Gagal membuka Gmail");
  }
}
async function syncLoginNotifState() {
  const toggle = document.getElementById("login-notif-toggle");
  if (!toggle || toggle.dataset.locked) return;

  try {
    const { stdout } = await exec(`getprop ${LOGIN_PROP}`);
    const enabled = stdout.trim() === "1";

    toggle.checked = enabled;
    localStorage.setItem(LOGIN_KEY, enabled ? "on" : "off");
  } catch {
    // fallback kalau getprop gagal
    toggle.checked = localStorage.getItem(LOGIN_KEY) === "on";
  }
}
async function setLoginNotifState(enabled) {
  await exec(`setprop ${LOGIN_PROP} ${enabled ? 1 : 0}`);
  localStorage.setItem(LOGIN_KEY, enabled ? "on" : "off");
}
function fetchTime() {
  if (!CurrentTime) return;
  CurrentTime.textContent = new Date().toLocaleTimeString();
}

function resetEngineUI() {
  updateEngineUI(false);
}

function setEngineUI(active, pid = null) {
  updateEngineUI(active, pid);
}

/* ===== CORE UI HANDLER ===== */
function updateEngineUI(active, pid = null) {
  const state = active ? "on" : "off";

  // dataset state
  StsEngine.dataset.state = state;

  // button state
  BtnOn.disabled  = active;
  BtnOff.disabled = !active;

  // cards & banner
  StatusCard.classList.toggle("active", active);
  VersionCard.classList.toggle("active", active);
  PidBanner.classList.toggle("active", active);

  // pid text
  PidText.textContent = active && pid ? pid : "N/A";

  // engine text + color (pakai class, bukan text detect)
  StsEngine.textContent = active ? "Actived" : "Disabled";
  StsEngine.classList.toggle("active", active);

  // sync engine logic
  setEngineState(state);

  // save once
  saveState({ engine: state });
}
function setEngineState(state) {
  if (!badge) return;

  badge.className = "engine-badge";

  if (state === "on") {
    badge.textContent = "SYSTEM";
    badge.classList.add("active");
  } else if (state === "locked") {
    badge.textContent = "ONLY VIP";
    badge.classList.add("locked");
  } else {
    badge.textContent = "SYSTEM";
  }
}
/* ========= FETCH ========= */
async function startRealtimeStats() {
  if (window.statsInterval) clearInterval(window.statsInterval);

  async function updateStats() {
    try {
      const { stdout } = await exec(
        "cat /data/local/tmp/forkt_stats.json 2>/dev/null || echo '{}'"
      );

      const data = JSON.parse(stdout || "{}");

      ramUsage.textContent = data.ram ?? "--";
      cpuUsage.textContent = data.cpu ?? "--";
      storageUsage.textContent = data.storage ?? "--";
      deviceUptime.textContent = data.uptime ?? "--";

      if (typeof data.ramPercent === "number")
        setProgress(ramBar, data.ramPercent);

      if (typeof data.cpuPercent === "number")
        setProgress(cpuBar, data.cpuPercent);

      if (typeof data.storagePercent === "number")
        setProgress(storageBar, data.storagePercent);

    } catch (e) {
      console.error("Stats error:", e);
    }
  }

  updateStats();
  window.statsInterval = setInterval(updateStats, 1000);
}
async function getEnginePID() {
  const { stdout } = await exec(
    "cat /data/local/tmp/forkt.pid 2>/dev/null || true"
  );
  return stdout.trim() || null;
}

async function isEngineAlive(pid) {
  if (!pid) return false;
  const { stdout } = await exec(`kill -0 ${pid} 2>/dev/null && echo ok || echo no`);
  return stdout.trim() === "ok";
}

async function rebuildEngineState() {
  engineActionLock = false;
  engineBooting = false;
  engineDesiredState = false;
  engineActualState = false;
  enginePID = null;

  const pid = await getEnginePID();
  if (!pid) { resetEngineUI(); return; }

  if (await isEngineAlive(pid)) {
    engineDesiredState = true;
    engineActualState = true;
    enginePID = pid;
    setEngineUI(true, pid);
  } else {
    resetEngineUI();
  }
}

async function fetchEngine() {
  if (engineActionLock || engineBooting) return;

  const pid = await getEnginePID();
  const alive = pid ? await isEngineAlive(pid) : false;

  if (engineDesiredState && alive) {
    engineActualState = true;
    enginePID = pid;
    setEngineUI(true, pid);
  } else if (!engineDesiredState) {
    resetEngineUI();
  }
}
function openAppModal(appName, pkg) {
  appNameEl.textContent = appName;
  targetApp = pkg;
  modal.style.display = 'flex';
}
/* ========= TOAST ========= */
const toast = document.getElementById("toast");
function showToast(msg) {
  if (!toast) return;

  clearTimeout(toast._hideTimer);
  clearTimeout(toast._showTimer);

  toast.textContent = msg;
  toast.style.display = "block";

  // reset state (sedikit lebih naik)
  toast.style.transition = "none";
  toast.style.opacity = "0";
  toast.style.transform = "translate(-50%, -6px) scale(.96)";

  requestAnimationFrame(() => {
    toast.style.transition =
      "opacity .28s ease, transform .28s cubic-bezier(.22,.61,.36,1)";
    toast.style.opacity = "1";
    toast.style.transform = "translate(-50%, -18px) scale(1)";
  });

  toast._hideTimer = setTimeout(() => {
    toast.style.opacity = "0";
    toast.style.transform = "translate(-50%, -8px) scale(.94)";

    toast._showTimer = setTimeout(() => {
      toast.style.display = "none";
    }, 280);
  }, 1850);
}

/* ========= SLIDER ========= */
function forceSliderRepaint(slider) {
  slider.style.display = 'none';
  slider.offsetHeight;
  slider.style.display = '';
}

function updateTouchUI() {
  if (!TouchSlider || !TouchValue) return;
  const min = Number(TouchSlider.min);
  const max = Number(TouchSlider.max);
  const val = Number(TouchSlider.value);

  TouchValue.textContent = val;

  const percent = ((val - min) / (max - min)) * 100;
  TouchSlider.style.setProperty("--percent", `${percent}%`);
}

function clampSlider(slider) {
  const min = Number(slider.min || 0);
  const max = Number(slider.max || 300);
  slider.value = Math.min(max, Math.max(min, slider.value));
}

function mapTouchSpeed(val) {
  return Math.max(-7, Math.min(7, Math.round((val - 150) / 20)));
}

/* ========= ACTION ========= */
SupportLink.addEventListener('click', () => {
  try { window.open('https://linktr.ee/kaitosettings','_blank','noopener,noreferrer'); } 
  catch { location.href = 'https://linktr.ee/kaitosettings'; }
});

/* ===== ENGINE ON/OFF ===== */
BtnOnSmart.addEventListener("click", async () => {
  // 🚫 BLOCK jika sedang proses boot engine
  if (engineActionLock) return showToast("Engine sedang diproses");
  if (!window.assertVipOrKillEngine()) return; // ⬅️ AMAN
  // ❌ FREE USER tidak boleh on
  if (!isVipUser()) {
    showToast("VIP Required");
    return;
  }

  engineActionLock = true;
  engineDesiredState = true;
  engineBooting = true;
  engineBootStart = Date.now();

  BtnOnSmart.disabled = true;

  try {
    const scriptPath = "/data/local/tmp/lex.sh";
    const logPath = "/data/local/tmp/lex.log";

    // pastikan file ada
    await exec(`test -f "${scriptPath}"`).catch(() => {
      throw new Error("lex.sh tidak ditemukan di /data/local/tmp");
    });

    // pastikan executable
    await exec(`chmod +x "${scriptPath}"`);

    // jalankan di background
    await exec(`sh -c 'nohup "${scriptPath}" > "${logPath}" 2>&1 &'`);

    showToast("Engine starting…");

    await sleep(800); // biar proses spawn dulu

    // polling PID max 5 detik
    let pid = null;
    for (let i = 0; i < 20; i++) {
      // ❌ TIDAK ADA SIDE EFFECT DI SINI
      pid = await getEnginePID();
      if (pid) break;
      await sleep(250);
    }

    if (!pid) throw new Error("PID engine tidak ditemukan");

    engineBooting = false;
    engineActualState = true;
    enginePID = pid;

    setEngineUI(true, pid);
    saveState({ engine: "on" });

    // ✅ ENGINE AKTIF
    setEngineState("on");
    showToast("Engine running");

  } catch (err) {
    console.error("Engine start error:", err);

    engineDesiredState = false;
    engineBooting = false;

    resetEngineUI();
    saveState({ engine: "off" });
    setEngineState("off");

    showToast("Gagal menjalankan engine");

  } finally {
    engineActionLock = false;
    BtnOnSmart.disabled = false;
  }
});

BtnOff.addEventListener('click', async () => {
  if (engineActionLock) return;

  engineActionLock = true;

  // ==== HARD STATE ====
  engineDesiredState = false;
  engineActualState = false;
  engineBooting = false;
  enginePID = null;

  // Guard agar tidak bisa auto-on
  engineForceOffUntil = Date.now() + ENGINE_OFF_GUARD;

  // UI lock
  BtnOff.disabled = true;
  BtnOn.disabled = false;

  try {
    await exec(`
      pkill -9 -f lex.sh 2>/dev/null
      pkill -9 -f forkt 2>/dev/null
      rm -f /data/local/tmp/forkt.pid
    `);

    resetEngineUI();
    saveState({ engine: "off" });
    showToast("Engine deactivated");

  } finally {
    engineActionLock = false;
  }
});

/* ===== TOGGLES ===== */
document.getElementById("network-optimizer-toggle")?.addEventListener("change", async e => {
  saveState({ networkOptimizer: e.target.checked });
  if (e.target.checked) {
    await exec("cmd settings put global netstats_enabled 0;cmd wifi remove-all-suggestions;cmd wifi set-ipreach-disconnect disabled;cmd wifi set-network-selection-config disabled enabled -a 0;cmd wifi set-network-selection-config enabled disabled -a 0;cmd wifi set-scan-always-available disabled;cmd wifi set-verbose-logging disabled -l 0;for a in $(cmd package list packages --user 0 network|cut -f2 -d:);do cmd activity force-stop $a&done");
    showToast("Network Optimized");
  } else {
    await exec("cmd settings delete global netstats_enabled");
    showToast("Network Restore");
  }
});
frameToggle.addEventListener("change", async e => {
  const enabled = e.target.checked;
  // simpan state walaupun engine OFF
  saveState({ frameOptimizer: enabled });
  try {
    await applyFrameOptimizer(enabled);
    showToast(
      enabled
        ? "Frame Optimizer enabled"
        : "Frame Optimizer disabled"
    );
  } catch (err) {
    console.error(err);
    // rollback UI jika gagal
    frameToggle.checked = !enabled;
    saveState({ frameOptimizer: !enabled });
    showToast("Gagal apply Frame Optimizer");
  }
});
chipsetToggle.addEventListener("change", async e => {
  if (chipsetToggle.dataset.locked) return;
  chipsetToggle.dataset.locked = "1";

  const enabled = e.target.checked;

  if (enabled && detectedChipset === "unknown") {
    chipsetToggle.checked = false;
    saveState({ chipsetBoost: false });
    refreshAllBadges();
    showToast("Chipset tidak terdeteksi");
    delete chipsetToggle.dataset.locked;
    return;
  }
  saveState({ chipsetBoost: enabled });

  try {
    await applyChipsetBoost(enabled);
  } catch {
    chipsetToggle.checked = false;
    saveState({ chipsetBoost: false });
    showToast("Failed apply Chipset Boost");
  } finally {
    refreshAllBadges();
    delete chipsetToggle.dataset.locked;
  }
});
romToggle.addEventListener("change", async e => {
  if (romToggle.dataset.locked) return;
  romToggle.dataset.locked = "1";

  const enabled = e.target.checked;
  saveState({ romBoost: enabled });

  if (!enabled) {
    refreshAllBadges();
    showToast("ROM Boost disabled");
    delete romToggle.dataset.locked;
    return;
  }

  if (detectedRom === "unknown") {
    romToggle.checked = false;
    saveState({ romBoost: false });
    refreshAllBadges();
    showToast("ROM tidak didukung");
    delete romToggle.dataset.locked;
    return;
  }

  try {
    await applyRomBoost(true);
  } catch {
    romToggle.checked = false;
    saveState({ romBoost: false });
    showToast("Failed apply ROM Boost");
  } finally {
    refreshAllBadges();
    delete romToggle.dataset.locked;
  }
});
adminToggle.addEventListener("click", () => {
  adminPanel.classList.toggle("minimized");
  adminToggle.textContent = adminPanel.classList.contains("minimized") ? "+" : "—";
});
loggingToggle.addEventListener("change", async e => {
  if (loggingToggle.dataset.locked) return;
  loggingToggle.dataset.locked = "1";

  const enabled = e.target.checked;
  saveState({ disableLogging: enabled });

  try {
    await applyDisableLogging(enabled);
  } catch {
    loggingToggle.checked = !enabled;
    showToast("Failed apply logging setting");
  } finally {
    delete loggingToggle.dataset.locked;
  }
});
/* ===== TABS ===== */
function initLoginNotifToggle() {
  const toggle = document.getElementById("login-notif-toggle");
  if (!toggle) return;

  toggle.addEventListener("change", async e => {
    if (toggle.dataset.locked) return;
    toggle.dataset.locked = "1";

    const enabled = e.target.checked;
    saveState({ loginNotif: enabled });
    showToast("apply login notification");

    try {
      await setLoginNotifState(enabled);
    } catch {
      toggle.checked = !enabled;
      showToast("Failed apply login notification");
    } finally {
      delete toggle.dataset.locked;
    }
  });
}
tabBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    const target = btn.dataset.tab;
    if (!tabs[target]) return; // safety check
    if (target === activeTab || tabLocked) return;

    tabLocked = true;

    tabBtns.forEach(b => b.classList.remove("active"));
    Object.values(tabs).forEach(t => t?.classList.remove("active")); // hapus semua active
    if (tabs[target]) tabs[target].classList.add("active");          // aktifkan target

    btn.classList.add("active");
    activeTab = target;

    setTimeout(() => tabLocked = false, 320);
  });
});
/* ===== TOUCH SLIDER ===== */
TouchSlider.addEventListener("input", () => updateTouchUI());

TouchSlider.addEventListener("change", async () => {
  const val = Number(TouchSlider.value);
  saveState({ touchSensitivity: val });

  const speed = mapTouchSpeed(val);
  try {
    await exec(`settings put system pointer_speed ${speed}`);
    showToast(`Sensitivity applied • ${val}`);
  } catch {
    showToast(`Failed apply sensitivity • ${val}`);
  }
});
SfApplyBtn.addEventListener("click", async () => {
  try {
    showToast("Applying SurfaceFlinger…");

    await exec(`
      sh -c '
      FPS=$(dumpsys display | grep -oE "fps=[0-9]+" | awk -F "=" "{print \\$2}" | head -n 1)
      [ -z "$FPS" ] && FPS=60

      VSYNC_OFFSET=$((-500000000 / FPS))
      DURATION=$((1000000 * (60 / FPS)))

      setprop debug.sf.early.app.duration "$DURATION"
      setprop debug.sf.late.app.duration "$DURATION"
      setprop debug.sf.early.sf.duration "$DURATION"
      setprop debug.sf.late.sf.duration "$DURATION"
      setprop debug.sf.set_idle_timer_ms 500
      setprop debug.sf.high_fps_early_app_phase_offset_ns "$VSYNC_OFFSET"
      setprop debug.sf.high_fps_late_sf_phase_offset_ns "$VSYNC_OFFSET"
      setprop debug.sf.layer_caching_active_layer_timeout_ms 500
      setprop debug.sf.vsync_phase_offset_ns "$VSYNC_OFFSET"
      setprop debug.sf.vsync_event_phase_offset_ns "$VSYNC_OFFSET"

      service call SurfaceFlinger 1035 >/dev/null 2>&1
      '
    `);

    showToast("SurfaceFlinger optimized");
    sfPulse();
    await fetchSurfaceFlingerFPS();
  } catch {
    showToast("Failed apply SurfaceFlinger");
  }
});
SfResetBtn.addEventListener("click", async () => {
  try {
    showToast("Resetting SurfaceFlinger…");

    await exec(`
      service call SurfaceFlinger 1035 >/dev/null 2>&1
    `);

    showToast("SurfaceFlinger reset");
  } catch {
    showToast("Reset failed");
  }
});
document.getElementById("btn-clear-cache")?.addEventListener("click", () => {
  if (!statusEl) return;

  statusEl.textContent = "Clearing cache…";
  showToast("Running system cleanup…");

  // jalankan shell async (tanpa blocking UI)
  runShellAsync(`
    # === APP & USER CACHE ===
    find /data/data/*/cache/* \
         /data/data/*/code_cache/* \
         /data/user_de/*/*/cache/* \
         /data/user_de/*/*/code_cache/* \
         /sdcard/Android/data/*/cache/* \
         -delete &>/dev/null

    pm trim-caches 1024G &>/dev/null

    # === SYSTEM CLEANUP ===
    {
      cmd stats clear-puller-cache
      cmd activity clear-debug-app
      cmd activity clear-watch-heap all
      cmd activity clear-exit-info all
      cmd activity clear-start-info all
      cmd content reset-today-stats

      cmd companiondevice refresh-cache
      cmd companiondevice remove-inactive-associations
      cmd blob_store clear-all-blobs
      cmd blob_store clear-all-sessions
      cmd device_policy clear-freeze-period-record

      wm tracing size 0
      cmd font clear
      cmd location_time_zone_manager clear_recorded_provider_states
      cmd lock_settings remove-cache

      cmd media.camera clear-stream-use-case-override
      cmd media.camera watch clear
      cmd safety_center clear-data

      cmd time_detector clear_network_time
      cmd time_detector clear_system_clock_network_time

      simpleperf --log fatal --log-to-android-buffer 0
      cmd settings put global activity_starts_logging_enabled 0

      cmd otadexopt cleanup
      dumpsys media.metrics --clear
      dumpsys procstats --clear
      cmd binder_calls_stats --reset

      cmd autofill destroy sessions
      dumpsys batterystats --reset
      dumpsys battery reset

      cmd usagestats clear-last-used-timestamps -a
      cmd package art cleanup
    } &>/dev/null

    # === DROP CACHES (SAFE) ===
    echo 3 > /proc/sys/vm/drop_caches
  `);

  // feedback cepat ke user
  setTimeout(() => {
    statusEl.textContent = "Cache cleared!";
    showToast("Cache & system cleaned");
  }, 1200);
});

// CLEAR STORAGE
document.getElementById("btn-clear-storage")?.addEventListener("click", () => {
  if (!statusEl) return;

  statusEl.textContent = "Optimizing storage…";
  showToast("Cleaning junk files…");

  runShellAsync(`
    {
    # === THUMBNAILS ===
    rm -rf /sdcard/DCIM/.thumbnails/* 2>/dev/null
    rm -rf /sdcard/Pictures/.thumbnails/* 2>/dev/null

    # === LOG FILES ===
    find /sdcard -type f \\( \
      -name "*.log" \
      -o -name "*.tmp" \
      -o -name "*.bak" \
      -o -name "*.trace" \
      -o -name "*.old" \
    \\) -delete 2>/dev/null

    # === APP CACHE ON STORAGE ===
    find /sdcard/Android/data/*/cache/* -delete 2>/dev/null

    # === EMPTY DIRS ===
    find /sdcard -type d -empty -delete 2>/dev/null
    } &>/dev/null
  `);

  setTimeout(() => {
    statusEl.textContent = "Storage optimized!";
    showToast("Storage cleaned safely");
  }, 1300);
});
/* ========= AUTO SYNC ========= */
setInterval(() => {
  if (!engineActionLock && !engineBooting) fetchEngine();
  fetchTime();
}, 2000);
setInterval(() => {
  if (!isVipUser() && engineState === "on") {
    console.warn("[ENGINE BLOCKED] FREE USER");
    exec("pkill -f lex.sh").catch(() => {});
    exec("rm -f /data/local/tmp/forkt.pid").catch(() => {});
    setEngineState("locked");
  }
}, 1000);
/* ========= INIT ========= */
document.addEventListener('DOMContentLoaded', async () => {
  /* ================= INIT UI ================= */
  clampSlider(TouchSlider);
  updateTouchUI();
  startRealtimeStats();
  checkUpdate();
  
  const toggle = document.getElementById("login-notif-toggle");
  if (!toggle) return;
  toggle.checked = localStorage.getItem(LOGIN_KEY) === "on";
  initLoginNotifToggle();
  syncLoginNotifState();
  requestAnimationFrame(() => {
    document.querySelector('.layout-menu')?.classList.add('ui-ready');
  });

  /* ================= DETECT DEVICE ================= */
  await detectDeviceShell();
  await initBoostStates();
  /* ================= LOAD STATE ================= */
  const saved = loadState();

  /* ================= TOUCH ================= */
  if (TouchSlider && saved.touchSensitivity) {
    TouchSlider.value = saved.touchSensitivity;
    updateTouchUI();
  }

  /* ================= FRAME ================= */
  if (frameToggle && typeof saved.frameOptimizer === "boolean") {
    frameToggle.checked = saved.frameOptimizer;
    if (saved.frameOptimizer) {
      applyFrameOptimizer(true).catch(() => {});
    }
  }

  /* ================= NETWORK ================= */
  const netToggle = document.getElementById("network-optimizer-toggle");
  if (netToggle && typeof saved.networkOptimizer === "boolean") {
    netToggle.checked = saved.networkOptimizer;
  }

  /* ================= CHIPSET BOOST ================= */
  if (chipsetToggle) {
    const canBoost = detectedChipset !== "unknown";
    const wantBoost = saved.chipsetBoost === true;

    chipsetToggle.disabled = !canBoost;
    chipsetToggle.checked = canBoost && wantBoost;

    if (canBoost && wantBoost) {
      applyChipsetBoost(true).catch(() => {
        chipsetToggle.checked = false;
        saveState({ chipsetBoost: false });
      });
    } else if (saved.chipsetBoost === true) {
      saveState({ chipsetBoost: false });
    }
  }

  /* ================= ROM BOOST ================= */
  if (romToggle) {
    const canBoost = detectedRom !== "unknown";
    const wantBoost = saved.romBoost === true;

    romToggle.disabled = !canBoost;
    romToggle.checked = canBoost && wantBoost;

    if (canBoost && wantBoost) {
      applyRomBoost(true).catch(() => {
        romToggle.checked = false;
        saveState({ romBoost: false });
      });
    } else if (saved.romBoost === true) {
      saveState({ romBoost: false });
    }
  }
  /* ================= AVAILABILITY + BADGES ================= */
  updateChipsetBoostAvailability();
  updateRomBoostAvailability();
  refreshAllBadges();

  /* ================= LOGGING ================= */
  if (loggingToggle && saved.disableLogging === true) {
    loggingToggle.checked = true;
    applyDisableLogging(true).catch(() => {});
  }
  /* ================= FINAL SYNC ================= */
  await fetchSurfaceFlingerFPS();
  await rebuildEngineState();
});
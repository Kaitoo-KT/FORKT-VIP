import { exec } from "https://cdn.jsdelivr.net/npm/kernelsu@1.0.6/+esm";

/* ================= CONFIG ================= */
const ADMIN_ANDROID_ID = "e42893a8e565a221";
const AUTO_GITHUB_TOKEN = "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";

const VIP_API =
  "https://api.github.com/repos/Kaitoo-KT/FORKT-VIP/contents/vip.json";

const TEMPKEY_API =
  "https://api.github.com/repos/Kaitoo-KT/FORKT-VIP/contents/tempkey.json";

/* ================= STATE ================= */
let adminBusy = false;
let countdownTimer = null;
let currentTempKey = null;

/* ================= INIT ================= */
document.addEventListener("DOMContentLoaded", async () => {
  await initAdmin();
  bindFreeUserUI();
});

/* ================= ADMIN CHECK ================= */
async function initAdmin() {
  const panel = document.getElementById("admin-panel");
  if (!panel) return;

  try {
    const { stdout } = await exec("settings get secure android_id");
    if (stdout?.trim() !== ADMIN_ANDROID_ID) {
      panel.remove();
      return;
    }

    panel.classList.add("show");
    document.getElementById("admin-token").value = AUTO_GITHUB_TOKEN;

    bindAdminVIP();
  } catch (e) {
    console.error("ADMIN INIT FAILED", e);
    panel.remove();
  }
}

/* ================= VIP ADMIN ================= */
function bindAdminVIP() {
  document.getElementById("admin-add").onclick = () => updateVIP("add");
  document.getElementById("admin-remove").onclick = () => updateVIP("remove");
}

const normalize = v => v.trim().toLowerCase();

async function updateVIP(action) {
  if (adminBusy) return;
  adminBusy = true;

  const status = document.getElementById("admin-status");
  const input = document.getElementById("admin-device-id");
  const deviceId = normalize(input.value);

  if (!deviceId) {
    status.textContent = "Device ID kosong";
    adminBusy = false;
    return;
  }

  try {
    status.textContent = "Fetching VIP list…";

    const res = await fetch(VIP_API, {
      headers: {
        Authorization: `token ${AUTO_GITHUB_TOKEN}`,
        Accept: "application/vnd.github+json"
      }
    });

    const file = await res.json();
    let vip = JSON.parse(atob(file.content)).vip || [];
    vip = vip.map(normalize);

    if (action === "add" && vip.includes(deviceId)) {
      status.textContent = "Sudah VIP ✔";
      return;
    }

    if (action === "remove" && !vip.includes(deviceId)) {
      status.textContent = "Tidak ditemukan ❌";
      return;
    }

    vip =
      action === "add"
        ? [...new Set([...vip, deviceId])]
        : vip.filter(v => v !== deviceId);

    await fetch(VIP_API, {
      method: "PUT",
      headers: {
        Authorization: `token ${AUTO_GITHUB_TOKEN}`,
        Accept: "application/vnd.github+json"
      },
      body: JSON.stringify({
        message: `VIP ${action}`,
        content: btoa(JSON.stringify({ vip }, null, 2)),
        sha: file.sha
      })
    });

    status.textContent = `VIP ${action === "add" ? "Added" : "Removed"} ✔`;
    input.value = "";
  } catch (e) {
    console.error(e);
    status.textContent = "VIP update error";
  } finally {
    adminBusy = false;
  }
}

/* ================= TEMP KEY ================= */
function bindFreeUserUI() {
  document.getElementById("free-add").onclick = createTempKey;
  document.getElementById("free-key-copy").onclick = copyTempKey;
}

async function createTempKey() {
  if (adminBusy) return;
  adminBusy = true;

  const status = document.getElementById("admin-status");
  const output = document.getElementById("free-key-output");
  const text = document.getElementById("free-key-text");

  try {
    const duration =
      document.querySelector('input[name="free-duration"]:checked')?.value || "5m";

    const now = Date.now();
    const expire =
      duration === "12h"
        ? now + 12 * 60 * 60 * 1000
        : now + 5 * 60 * 1000;

    const key = `FORKT-${Math.floor(100000 + Math.random() * 900000)}`;
    currentTempKey = key;

    status.textContent = "Generating TEMP KEY…";

    const res = await fetch(TEMPKEY_API, {
      headers: {
        Authorization: `token ${AUTO_GITHUB_TOKEN}`,
        Accept: "application/vnd.github+json"
      }
    });

    let sha = null;
    let data = { keys: {} };

    if (res.ok) {
      const file = await res.json();
      sha = file.sha;
      data = JSON.parse(atob(file.content)) || { keys: {} };
    }

    // 🧹 CLEAN EXPIRED
    Object.keys(data.keys).forEach(k => {
      if (data.keys[k].expire <= now) delete data.keys[k];
    });

    data.keys[key] = { created: now, expire };

    await fetch(TEMPKEY_API, {
      method: "PUT",
      headers: {
        Authorization: `token ${AUTO_GITHUB_TOKEN}`,
        Accept: "application/vnd.github+json"
      },
      body: JSON.stringify({
        message: `Add TEMP KEY ${key}`,
        content: btoa(JSON.stringify(data, null, 2)),
        sha
      })
    });

    text.value = key;
    output.style.display = "flex";
    startCountdown(expire);
    status.textContent = "TEMP KEY created ✔";
  } catch (e) {
    console.error(e);
    status.textContent = "TEMP KEY error";
  } finally {
    adminBusy = false;
  }
}

/* ================= COUNTDOWN ================= */
function startCountdown(expire) {
  clearInterval(countdownTimer);

  countdownTimer = setInterval(() => {
    const remain = expire - Date.now();
    const text = document.getElementById("free-key-text");

    if (remain <= 0) {
      text.value = `${currentTempKey} | EXPIRED`;
      clearInterval(countdownTimer);
      return;
    }

    const m = Math.floor(remain / 60000);
    const s = Math.floor((remain % 60000) / 1000);
    text.value = `${currentTempKey} | ${m}m ${s}s`;
  }, 1000);
}

function copyTempKey() {
  if (!currentTempKey) return;
  navigator.clipboard.writeText(currentTempKey);
}
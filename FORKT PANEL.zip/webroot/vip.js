import { exec } from "https://cdn.jsdelivr.net/npm/kernelsu@1.0.6/+esm";

const VIP_RAW_URL =
  "https://raw.githubusercontent.com/Kaitoo-KT/FORKT-VIP/refs/heads/main/vip.json";
const TEMP_KEY_RAW_URL =
  "https://raw.githubusercontent.com/Kaitoo-KT/FORKT-VIP/main/tempkey.json";
const GITHUB_API_URL =
  "https://api.github.com/repos/Kaitoo-KT/FORKT-VIP/contents/vip.json";
const StsEngine = document.getElementById('sts-engine-id');
const PidText = document.getElementById('engine-pid-id');
const engineCard = document.querySelector('.layout-info.status-engine');
const timerEl = document.getElementById("vip-timer");
let currentVipState = false;
let androidIdCache = null;
let vipTimer = null;
let lastVipState = null;
let engineState = "off"; 
let tempVipExpire = null;
let tempVipTimer = null;
window.currentVipState = false;
/* ================= FETCH VIP RAW ================= */
function isEngineAllowed() {
  return isPermanentVip() === true;
}
function computeVipState() {
  return isPermanentVip(); // TEMP VIP TIDAK DIHITUNG SAAT LOAD
}
function markVipVerified(isValid) {
  localStorage.setItem("forkt_vip_verified", isValid ? "1" : "0");
}
function savePermanentVip(isVip) {
  localStorage.setItem("forkt_vip_permanent", isVip ? "1" : "0");
}

function isPermanentVip() {
  return localStorage.getItem("forkt_vip_permanent") === "1";
}
function saveTempVip(expire) {
  localStorage.setItem("forkt_temp_vip_expire", String(expire));
}

function loadTempVipExpire() {
  return Number(localStorage.getItem("forkt_temp_vip_expire") || 0);
}

function clearTempVip() {
  localStorage.removeItem("forkt_temp_vip_expire");
}

function isTempVipActive() {
  const exp = loadTempVipExpire();
  return exp > Date.now();
}
function updateVipTimer(text, expired = false) {
  const timer = document.getElementById("vip-timer");
  if (!timer) return;

  const timeEl = timer.querySelector(".vip-timer-time");

  if (!text) {
    timer.classList.remove("active", "expired");
    timer.style.display = "none";
    return;
  }

  timeEl.textContent = text;

  timer.style.display = "inline-flex";
  timer.classList.toggle("active", !expired);
  timer.classList.toggle("expired", expired);
}
async function fetchVIPFast() {
  const res = await fetch(GITHUB_API_URL, {
    headers: { Accept: "application/vnd.github+json" }
  });
  const file = await res.json();
  const content = JSON.parse(atob(file.content));
  return Array.isArray(content.vip) ? content.vip : [];
}
async function checkInternetAndPing() {
  try {
    const start = performance.now();
    const res = await fetch("https://www.google.com/generate_204", {
      method: "GET",
      cache: "no-store",
      mode: "no-cors"
    });
    const ping = Math.round(performance.now() - start);
    return { online: true, ping };
  } catch {
    return { online: false, ping: null };
  }
}
async function validateTempKey(key) {
  // 1️⃣ Validasi format key
  if (!/^FORKT-\d{6}$/.test(key)) return null;

  try {
    const res = await fetch(TEMP_KEY_RAW_URL + "?t=" + Date.now(), {
      cache: "no-store"
    });
    if (!res.ok) return null;

    const data = await res.json();

    // 2️⃣ Pastikan struktur benar
    if (!data.keys || !data.keys[key]) return null;

    const keyData = data.keys[key];

    // 3️⃣ 🔥 INI TEMPAT POTONGAN KAMU 🔥
    if (Date.now() > keyData.expire) {
      return null; // key expired
    }

    // 4️⃣ Valid → return expire timestamp
    return keyData.expire;

  } catch (e) {
    console.error("TEMP KEY VALIDATION ERROR:", e);
    return null;
  }
}
function startTempVipCountdown(expire, statusText) {
  clearInterval(tempVipTimer);

  tempVipTimer = setInterval(() => {
    const left = expire - Date.now();

    if (left <= 0) {
      clearInterval(tempVipTimer);
      clearTempVip();

      statusText.textContent = "VIP expired ❌";
      updateVipTimer("EXPIRED", true); // ⬅️ DI SINI

      setEngineState("locked");
      disableVIPFeatures();

      setTimeout(() => updateVipTimer(null), 2500); // ⬅️ auto hide
      location.reload();
      return;
    }

    const m = Math.floor(left / 60000);
    const s = Math.floor((left % 60000) / 1000);

    updateVipTimer(`${m}m ${s}s`); // ⬅️ AKTIF
  }, 1000);
}

/* ================= INIT ================= */
document.addEventListener("DOMContentLoaded", () => {
  const vipInput   = document.getElementById("vip-input");
  const vipEnter   = document.getElementById("vip-enter");
  const statusText = document.getElementById("vip-status");
  const gate       = document.getElementById("vip-gate");
  if (!isPermanentVip()) {
    clearTempVip();          // hapus expire
    updateVipTimer(null);    // sembunyikan timer
  }
  if (!vipInput || !vipEnter || !statusText || !gate) return;
  unlockUI(gate, false);
  // 🔒 CEK STATE VALID
  let isVipUser = computeVipState();
  currentVipState = isVipUser;
  if (!isTempVipActive()) {
    updateVipTimer(null); // ⬅️ pastikan hidden
  }
  /* ================= INIT UI ================= */
  if (isVipUser) {
    vipInput.style.display = "none";
    vipEnter.disabled = false;
    statusText.textContent = "VIP Access";
  } else {
    vipInput.style.display = "block";
    vipEnter.disabled = true;
    statusText.textContent = "Enter VIP Key";

    vipInput.oninput = () => {
      vipEnter.disabled = vipInput.value.trim() === "";
    };
  }

  /* ================= CLICK ENTER ================= */
  vipEnter.onclick = async () => {
  // BLOK TOTAL kalau belum VIP & input kosong
  if (!isVipUser && vipInput.value.trim() === "") {
    statusText.textContent = "Masukkan key terlebih dahulu";
    return;
  }

  if (isVipUser) {
    unlockUI(gate, true);
    return;
  }

  const key = vipInput.value.trim();
  statusText.textContent = "Validating key…";

  const expire = await validateTempKey(key);

  if (!expire) {
    statusText.textContent = "Invalid / expired key ❌";
    vipInput.classList.add("error");
    unlockUI(gate, false); // 🔒 PASTI TERTUTUP
    return;
  }

  vipInput.classList.remove("error");
  saveTempVip(expire);
  isVipUser = true;
  currentVipState = true;

  statusText.textContent = "VIP Temporary ✔";
  unlockUI(gate, true);
  startTempVipCountdown(expire, statusText);
};

  /* ================= INIT VIP CHECK ================= */
  initVIP(isVipUser);
  startRealtimeVIP();
});
async function initVIP(isFirstLoad = false) {
  const gate = document.getElementById("vip-gate");
  const statusText = document.getElementById("vip-status");
  const enterBtn = document.getElementById("vip-enter");
  const pingEl = document.getElementById("vip-ping"); // ⬅️ ELEMENT BARU
  
  if (!gate || !statusText || !enterBtn) return;

  if (!androidIdCache) {
    const { stdout } = await exec("settings get secure android_id");
    androidIdCache = stdout?.trim();
  }

  if (isFirstLoad) statusText.textContent = "Checking connection…";

  // 🌐 CEK INTERNET + PING
  const net = await checkInternetAndPing();

  if (pingEl) {
    pingEl.textContent = net.online
      ? `Ping ${net.ping} ms`
      : "Offline";
    pingEl.classList.toggle("offline", !net.online);
  }

  // ❌ OFFLINE → PAKAI STATE TERAKHIR
  if (!net.online) {
    updateVipState(isTempVipActive(), gate, statusText, enterBtn);
    statusText.textContent = "Offline mode";
    return;
  }

  // ✅ ONLINE → FETCH NORMAL
  try {
    const vipList = await fetchVIPFast();
    const isVIP = vipList.includes(androidIdCache);

    markVipVerified(isVIP);
    savePermanentVip(isVIP);
    
    updateVipState(
      isVIP || isTempVipActive(),
      gate,
      statusText,
      enterBtn
    );
  } catch (e) {
    console.warn("VIP fetch failed, fallback cache", e);
    updateVipState(isTempVipActive(), gate, statusText, enterBtn);
    statusText.textContent = "Offline mode";
  }
}

/* ================= REALTIME VIP ================= */
function startRealtimeVIP() {
  stopRealtimeVIP();
  vipTimer = setInterval(() => initVIP(false), 2500); // polling 2.5 detik
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) initVIP(false);
  });
}

function stopRealtimeVIP() {
  if (vipTimer) clearInterval(vipTimer);
}
/* ================= STATE MANAGER ================= */
function updateVipState(isVip, gate, statusText, enterBtn) {
  // ✅ FINAL VIP STATE (Permanent OR Temp)
  const finalVip = isVip === true || isTempVipActive();

  currentVipState = finalVip;
  setDeviceStatus(finalVip);

  if (finalVip) {
    // ===== VIP USER =====
    statusText.textContent = "VIP Access";

    engineCard?.classList.add("status-vip");
    engineCard?.classList.remove("status-free");

    enterBtn.disabled = false;
    enterBtn.classList.add("active");

    // engine default OFF
    setEngineState("off");

    if (StsEngine) StsEngine.textContent = "Deactivated";
    if (PidText) PidText.textContent = "N/A";

  } else {
    // ===== FREE USER =====
    statusText.textContent = "FREE USER - VIP REQUIRED";
    if (isTempVipActive() && !isPermanentVip()) {
    document.getElementById("engine-badge").textContent = "PERMANENT VIP ONLY";
    disableVIPFeatures();
    }
    updateVipTimer(null); // sembunyikan timer
    engineCard?.classList.add("status-free");
    engineCard?.classList.remove("status-vip");

    enterBtn.disabled = false;
    enterBtn.classList.add("active");

    // 🔒 HARD LOCK ENGINE
    setEngineState("locked");

    if (StsEngine) StsEngine.textContent = "VIP REQUIRED";
    if (PidText) PidText.textContent = "Free User";

    // 🧹 Pastikan tidak ada engine/shell hidup
    exec("pkill -f lex.sh").catch(()=>{});
    exec("rm -f /data/local/tmp/forkt.pid").catch(()=>{});
    setEngineState("locked");
  }
}

/* ================= STATUS BADGE ================= */
function setDeviceStatus(isVip) {
  if (lastVipState === isVip) return;
  lastVipState = isVip;

  const badge = document.getElementById("device-status");
  if (!badge) return;

  const card = badge.closest(".device-status-card");
  const dot = document.querySelector(".vip-dot");

  badge.classList.remove("vip-badge", "free-badge");
  card?.classList.remove("vip", "free");
  dot?.classList.remove("vip", "free");

  if (isVip) {
    badge.textContent = "VIP USER";
    badge.classList.add("vip-badge");
    card?.classList.add("vip");
    dot?.classList.add("vip");
  } else {
    badge.textContent = "FREE USER";
    badge.classList.add("free-badge");
    card?.classList.add("free");
    dot?.classList.add("free");
  }
}

/* ================= UNLOCK UI ================= */
function unlockUI(gate, isVip) {
  if (!(isVip === true || isTempVipActive())) {
    console.warn("[BLOCKED] FREE USER ATTEMPT");
    return;
  }

  gate.classList.add("hide");

  setTimeout(() => {
    gate.remove();
    document.querySelector(".layout-menu")?.classList.add("ui-ready");
    setDeviceStatus(true);
    animateVIPDots();
  }, 450);
}
function animateVIPDots() {
  document.querySelectorAll('.vip-dot').forEach(dot => {
    dot.animate([
      { transform: 'scale(1)', opacity: 1 },
      { transform: 'scale(1.3)', opacity: 0.8 },
      { transform: 'scale(1)', opacity: 1 }
    ], {
      duration: 1400,
      iterations: Infinity
    });
  });
}
export function isVipUser() {
  return currentVipState === true;
}
function setEngineState(state) {
  if (state === "on" && !isPermanentVip()) {
    console.warn("[ENGINE BLOCKED] TEMP/FREE USER");

    exec("pkill -f lex.sh").catch(()=>{});
    exec("rm -f /data/local/tmp/forkt.pid").catch(()=>{});

    state = "locked";
  }

  engineState = state;
  const badge = document.getElementById("engine-badge");
  const engineCard = document.querySelector(".layout-info.status-engine");
  const bannerPid = document.querySelector(".banner-pid");

  if (!badge || !engineCard) return;

  badge.className = "engine-badge";
  engineCard.classList.remove("active", "locked");
  bannerPid?.classList.remove("active");

  switch (state) {
    case "on":
      badge.textContent = "SYSTEM";
      badge.classList.add("active");
      engineCard.classList.add("active");
      bannerPid?.classList.add("active");
      if (StsEngine) StsEngine.textContent = "Activated";
      break;

    case "locked":
      badge.textContent = "VIP";
      badge.classList.add("locked");
      engineCard.classList.add("locked");
      if (StsEngine) StsEngine.textContent = "VIP REQUIRED";
      break;

    default:
      badge.textContent = "SYSTEM";
      if (StsEngine) StsEngine.textContent = "Deactivated";
      break;
  }
}
/* ================= DISABLE VIP FEATURES ================= */
function disableVIPFeatures() {
  document.querySelectorAll("#BtnOnSmart, #BtnOffSmart, #sf-apply, #sf-reset").forEach(btn => {
    btn.disabled = true;
    btn.title = "VIP Required";
  });
  document.querySelectorAll("#frame-optimizer-toggle, #network-optimizer-toggle").forEach(el => {
    el.disabled = true;
    el.title = "VIP Required";
  });
  const slider = document.getElementById("touch-sensitivity");
  if (slider) {
    slider.disabled = true;
    slider.title = "VIP Required";
  }
  document.querySelectorAll("#device-boost button").forEach(btn => {
    btn.disabled = true;
    btn.title = "VIP Required";
  });
}
export function assertVipOrKillEngine() {
  // ❌ TEMP VIP TIDAK BOLEH ENGINE
  if (!isPermanentVip()) {
    console.warn("[ENGINE BLOCKED] NOT PERMANENT VIP");

    exec("pkill -f lex.sh").catch(()=>{});
    exec("rm -f /data/local/tmp/forkt.pid").catch(()=>{});

    setEngineState("locked");
    return false;
  }
  return true;
}

// ⬇️ WAJIB GLOBAL (biar script.js bisa akses)
window.assertVipOrKillEngine = assertVipOrKillEngine;
// 🔒 Lock VIP state agar tidak bisa dimodifikasi script lain
Object.defineProperty(window, "currentVipState", {
  writable: false,
  configurable: false
});
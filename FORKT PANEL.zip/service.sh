#!/system/bin/sh
# ===============================
# FORKT PANEL - service.sh
# ===============================

# ==== RESOLVE MODULE DIR (ANTI AX BUG) ====
MODDIR="$(cd "$(dirname "$0")" && pwd)"

# ==== PATH DEFINITIONS ====
SCRIPT_PATH="$MODDIR/system/lex.sh"
DEVICE_PATH="$MODDIR/system/stats.sh"
CHIPSET_PATH="$MODDIR/system/chipset.sh"
GAME_PATH="$MODDIR/system/game.txt"

TARGET_PATH="/data/local/tmp/lex.sh"
TARGET_GAME="/data/local/tmp/game.txt"

# ==== LOAD BANNER FROM module.prop ====
BANNER_REL="$(grep '^banner=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)"
IMG="$MODDIR$BANNER_REL"

# ==== SAFE LOG PATH ====
LOG_PATH="/data/local/tmp/forkt.log"

# ==== VALIDATION ====
if [ ! -f "$SCRIPT_PATH" ]; then
  am start -a AxManager.TOAST -e text "Error: lex.sh tidak ditemukan"
  exit 1
fi

# ==== CHECK ALREADY RUNNING ====
if pgrep -f "$TARGET_PATH" >/dev/null; then
  am start -a AxManager.TOAST -e text "Forkt sudah aktif"
  exit 0
fi

# ==== PREPARE FILES ====
cp -f "$SCRIPT_PATH" "$TARGET_PATH"
chmod 755 "$TARGET_PATH"

[ -f "$GAME_PATH" ] && cp -f "$GAME_PATH" "$TARGET_GAME"

# ==== START SERVICES ====
nohup "$DEVICE_PATH" >> "$LOG_PATH" 2>&1 &
nohup "$CHIPSET_PATH" >> "$LOG_PATH" 2>&1 &

sleep 0.6

# ==== STATUS CHECK ====
if pgrep -f "$DEVICE_PATH" >/dev/null; then
  am start -a AxManager.TOAST -e text "Forkt Activated"
else
  am start -a AxManager.TOAST -e text "Forkt gagal dijalankan"
fi

# ========== SYSTEM CLEANUP ==========
cmd autofill set log_level off
cmd display ab-logging-disable
cmd display dmd-logging-disable
cmd display dwb-logging-disable
cmd miui_step_counter_service logging-disable
cmd voiceinteraction set-debug-hotword-logging false
cmd wifi set-verbose-logging disabled -l 0
cmd window logging disable
cmd window logging disable-text
cmd window logging stop
cmd thermalservice override-status 0
logcat -G 8m
setprop debug.sf.multithreaded_present 1
setprop debug.sf.showupdates 0
setprop debug.sf.luma_sampling 0
setprop debug.sf.frame_rate_multiple_threshold 120
setprop debug.sf.set_binder_thread_rt 1

# ========== NOTIFICATION ==========
if [ -n "$BANNER_REL" ] && [ -f "$IMG" ]; then
  cmd notification post \
    -S bigpicture \
    -i "$IMG" \
    -I "$IMG" \
    FORKT_PANEL \
    "FORKT PANEL" \
    "Installed successfully"
else
  cmd notification post \
    FORKT_PANEL \
    "FORKT PANEL" \
    "Installed successfully"
fi

exit 0
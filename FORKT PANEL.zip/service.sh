#!/system/bin/sh
# ==== RESOLVE REAL PATH (ANTI AX BUG) ====
SCRIPT_PATH="${0%/*}/system/lex.sh"
DEVICE_PATH="${0%/*}/system/stats.sh"
CHIPSET_PATH="${0%/*}/system/chipset.sh"
TARGET_PATH="/data/local/tmp/lex.sh"
GAME_PATH="${0%/*}/system/game.txt"
TARGET_GAME="/data/local/tmp/game.txt"
# ==== CEK FILE SCRIPT ADA ====
if [ ! -f "$SCRIPT_PATH" ]; then
    am start -a AxManager.TOAST -e text "Error: lex.sh tidak ditemukan"
    exit 1
fi

# ==== CEK LOKASI LOG AMAN ====
LOG_PATH="/dev/null"

# Kalau /system read-only → pindah ke /data/local/tmp
if ! touch "$LOG_PATH" 2>/dev/null; then
    LOG_PATH="/data/local/tmp/lex.log"
fi

# ==== CEK SUDAH BERJALAN BELUM ====
PID_EXIST=$(pgrep -f "$SCRIPT_PATH")
if [ -n "$PID_EXIST" ]; then
    am start -a AxManager.TOAST -e text "Forkt sudah aktif"
    exit 0
fi

# ==== START BACKGROUND PROCESS ====
cp "$SCRIPT_PATH" "$TARGET_PATH"
cp "$GAME_PATH" "$TARGET_GAME"


# Jalankan script
nohup "$DEVICE_PATH" > "$LOG_PATH" 2>&1 &
nohup "$CHIPSET_PATH" > "$LOG_PATH" 2>&1 &
sleep 0.5

# ==== CEK BERHASIL JALAN ====
if [ -f "$TARGET_PATH" ] && [ -x "$TARGET_PATH" ]; then
    am start -a AxManager.TOAST -e text "Forkt Activated"
else
    am start -a AxManager.TOAST -e text "lex.sh tidak ditemukan atau tidak executable"
fi
# ============= CLEAN UP SYSTEM JUNK =================
cmd autofill set log_level off
cmd display ab-logging-disable
cmd display dmd-logging-disable
cmd display dwb-logging-disable
cmd miui_step_counter_service logging-disable
cmd voiceinteraction set-debug-hotword-logging false
cmd wifi set-verbose-logging disabled -l 0
cmd window logging disable
cmd window logging disable-text
cmd window logging stop
cmd thermalservice override-status 0
logcat -G 8m
setprop debug.sf.multithreaded_present 1
setprop debug.sf.showupdates 0
setprop debug.sf.luma_sampling 0
setprop debug.sf.frame_rate_multiple_threshold 120
setprop debug.sf.set_binder_thread_rt 1
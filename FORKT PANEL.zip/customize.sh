echo "
╭━━━┳━━━┳━━━┳╮╭━┳━━━━╮
┃╭━━┫╭━╮┃╭━╮┃┃┃╭┫╭╮╭╮┃
┃╰━━┫┃╱┃┃╰━╯┃╰╯╯╰╯┃┃╰╯
┃╭━━┫┃╱┃┃╭╮╭┫╭╮┃╱╱┃┃
┃┃╱╱┃╰━╯┃┃┃╰┫┃┃╰╮╱┃┃
╰╯╱╱╰━━━┻╯╰━┻╯╰━╯╱╰╯
"
sleep 0.3
echo "   ├[-] Developer : @forkt | @sukitovone"
sleep 0.3
echo "   └[-] Credit Module"
echo "       - WebUi By @rxysettings"
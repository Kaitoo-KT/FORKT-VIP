#!/system/bin/sh

# Ambil nama device
DEVICE_NAME=$(getprop ro.product.marketname)
ANDROID_VER=$(getprop ro.build.version.release)

INFO="$DEVICE_NAME (Android $ANDROID_VER)"

sed -i "s|\${DEVICE_NAME}|$INFO|g" $MODPATH/module.prop

RED="\033[0;31m"
GREEN="\033[0;32m"
YELLOW="\033[0;33m"
CYAN="\033[0;36m"
RESET="\033[0m"

===== Banner ASCII =====

echo -e "${CYAN}
╭━━━┳━━━┳━━━┳╮╭━┳━━━━╮
┃╭━━┫╭━╮┃╭━╮┃┃┃╭┫╭╮╭╮┃
┃╰━━┫┃╱┃┃╰━╯┃╰╯╯╰╯┃┃╰╯
┃╭━━┫┃╱┃┃╭╮╭┫╭╮┃╱╱┃┃
┃┃╱╱┃╰━╯┃┃┃╰┫┃┃╰╮╱┃┃
╰╯╱╱╰━━━┻╯╰━┻╯╰━╯╱╰╯${RESET}
"
sleep 0.2

===== Info Developer =====

echo -e "${YELLOW}   ├[-] Developer : @forkt | @sukitovone${RESET}"
sleep 0.3

===== Credit Module =====

echo -e "${GREEN}   └[-] Credit Module${RESET}"
echo -e " ${RED}      - WebUI By @rxysettings"
echo -e "${CYAN}-----------------------------------------${RESET}"